<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Student Dashboard</title>
  <link rel="stylesheet" href="../student/dashbaord.css">
</head>
<body>
  <h2>Welcome Student</h2>
  <form action="../php/upload_assignment.php" method="POST" enctype="multipart/form-data">
    <label for="file">Upload Assignment:</label>
    <input type="file" name="file" required>
    <input type="submit" value="Upload">
  </form>

  <h3>Your Submissions:</h3>
  <?php include '../php/student_submissions.php'; ?>

  <br><a href="../php/logout.php">Logout</a>
</body>
</html>
