<?php include '../php/student_session_check.php'; ?>
<!DOCTYPE html>
<html>
<head>
  <title>Student Dashboard</title>
  <style>
  
    * {
        box-sizing: border-box;
    }

    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #121212;
        color: #e0e0e0;
        margin: 0;
        padding: 0;
        line-height: 1.6;
    }

    
    body > * {
        max-width: 900px;
        margin: 40px auto;
        padding: 30px 40px;
        background-color: #1e1e1e;
        border-radius: 16px;
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.4);
        transition: all 0.3s ease;
    }

    
    h2 {
        font-size: 32px;
        margin-bottom: 20px;
        color: #ffffff;
        text-align: center;
    }

    h3 {
        font-size: 24px;
        margin-top: 40px;
        color: #cccccc;
    }

    
    form {
        display: flex;
        flex-direction: column;
        gap: 15px;
        margin-bottom: 30px;
        padding: 20px;
        background-color: #2a2a2a;
        border: 1px solid #333;
        border-radius: 12px;
    }

    label {
        font-weight: 600;
        color: #dddddd;
    }

    input[type="file"] {
        padding: 10px;
        border-radius: 8px;
        border: 1px solid #444;
        background-color: #1e1e1e;
        color: #eee;
        font-size: 14px;
    }

    input[type="submit"] {
        background: linear-gradient(135deg, #3498db, #2980b9);
        color: white;
        border: none;
        padding: 12px 20px;
        border-radius: 8px;
        font-weight: bold;
        cursor: pointer;
        font-size: 15px;
        transition: background 0.3s ease, transform 0.2s;
    }

    input[type="submit"]:hover {
        background: linear-gradient(135deg, #2980b9, #2471a3);
        transform: translateY(-2px);
    }

    
    p {
        padding: 15px 20px;
        background-color: #292929;
        border-left: 6px solid #3498db;
        border-radius: 8px;
        margin-bottom: 15px;
        font-size: 15px;
        transition: background-color 0.3s ease;
    }

    p:hover {
        background-color: #323232;
    }

    
    a {
        display: inline-block;
        color: #3498db;
        text-decoration: none;
        font-weight: 600;
        margin-top: 20px;
        transition: color 0.3s ease, text-decoration 0.3s ease;
    }

    a:hover {
        color: #5dade2;
        text-decoration: underline;
    }

   
    @media (max-width: 600px) {
        body > * {
            padding: 20px;
        }

        form {
            padding: 15px;
        }

        h2 {
            font-size: 26px;
        }

        h3 {
            font-size: 20px;
        }
    }
  </style>
</head>
<body>
  <h2>Welcome Student</h2>

  <form id="uploadForm" enctype="multipart/form-data">
    <label for="file">Upload Assignment:</label>
    <input type="file" name="file" required>
    <input type="submit" value="Upload">
  </form>

  <h3>Your Submissions:</h3>
  <div id="submissions">
    <?php include '../php/student_submissions.php'; ?>
  </div>

  <br><a href="../php/logout.php">Logout</a>


  <script>
    let timer;
    function resetTimer() {
      clearTimeout(timer);
      timer = setTimeout(() => {
        window.location.href = "../php/logout.php";
      }, 10000);
    }

    window.onload = resetTimer;
    document.onmousemove = resetTimer;
    document.onkeypress = resetTimer;
  </script>

  <script>
    document.getElementById('uploadForm').addEventListener('submit', function(e) {
      e.preventDefault();
      
      const formData = new FormData(this);

      fetch('../php/upload_assignment.php', {
        method: 'POST',
        body: formData
      })
      .then(response => response.text())
      .then(data => {
        alert(data.trim());

        
        fetch('../php/student_submissions.php')
          .then(response => response.text())
          .then(html => {
            document.getElementById('submissions').innerHTML = html;
          });
        
        document.getElementById('uploadForm').reset();
      })
      .catch(err => {
        console.error('Error:', err);
        alert("Upload failed.");
      });
    });
  </script>
</body>
</html>
