<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Faculty Dashboard</title>
    <link rel="stylesheet" href="../faculty/dashboard.css">
</head>
<body>
    <div class="dashboard-container">
        <h1>Welcome Faculty</h1>

        <!-- Success message -->
        <?php if (isset($_GET['updated']) && $_GET['updated'] == 1): ?>
            <div class="alert success">✅ Grade and comment updated successfully.</div>
        <?php endif; ?>

        <!-- Error message -->
        <?php if (isset($_GET['error']) && $_GET['error'] == 1): ?>
            <div class="alert error">❌ Error updating assignment. Please try again.</div>
        <?php endif; ?>

        <h2>Submitted Assignments</h2>
        <div class="assignments-list">
            <?php include '../php/view_submissions.php'; ?>
        </div>

        <div class="logout-link">
            <a href="../php/logout.php">Logout</a>
        </div>
    </div>
</body>
</html>
