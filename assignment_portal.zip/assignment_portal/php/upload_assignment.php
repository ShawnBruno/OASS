<!-- php/upload_assignment.php -->
<?php
include 'db.php';
session_start();

if ($_FILES['file']['error'] == 0) {
  $filename = $_FILES['file']['name'];
  $filepath = '../uploads/' . $filename;
  move_uploaded_file($_FILES['file']['tmp_name'], $filepath);

  $user_id = $_SESSION['user_id'];
  $sql = "INSERT INTO assignments (user_id, filename) VALUES ($user_id, '$filename')";
  mysqli_query($conn, $sql);

  echo "Assignment uploaded successfully. <a href='../student/dashboard.html'>Go back</a>";
} else {
  echo "Upload failed.";
}
?>