<?php
include 'db.php'; 
session_start();

if ($_FILES['file']['error'] == 0) {
    $filename = $_FILES['file']['name'];
    $filepath = '../uploads/' . $filename;

    if (move_uploaded_file($_FILES['file']['tmp_name'], $filepath)) {
        $user_id = $_SESSION['user_id'];
        $stmt = $conn->prepare("INSERT INTO assignments (user_id, filename) VALUES (?, ?)");
        $stmt->bind_param("is", $user_id, $filename);
        $stmt->execute();
        $stmt->close();
        echo "Uploaded successfully.";
    } else {
        echo "Error moving file.";
    }
} else {
    echo "Upload failed.";
}
?>
