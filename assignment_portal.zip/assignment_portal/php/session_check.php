<?php
session_start();

function enforce_session($required_role = null, $timeout_duration = 5) {
    if (!isset($_SESSION['user_id']) || ($required_role && $_SESSION['role'] !== $required_role)) {
        header("Location: ../login.php");
        exit();
    }

    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
        session_unset();
        session_destroy();
        header("Location: ../login.php?timeout=1");
        exit();
    }

    $_SESSION['LAST_ACTIVITY'] = time();
}
?>
