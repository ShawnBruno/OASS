<?php
include 'db.php';

if (isset($_POST['id']) && isset($_POST['grade']) && isset($_POST['comment'])) {
    $id = $_POST['id'];
    $grade = mysqli_real_escape_string($conn, $_POST['grade']);
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);

    $sql = "UPDATE assignments SET grade='$grade', comment='$comment' WHERE id=$id";

    if (mysqli_query($conn, $sql)) {
        header("Location: ../faculty/dashboard.php?updated=1");
        exit();
    } else {

        echo "Error updating record: " . mysqli_error($conn);
        exit();
    }
} else {

    header("Location: ../faculty/dashboard.php?error=1");
    exit();
}
?>
