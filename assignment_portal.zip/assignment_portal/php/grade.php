<?php
include 'db.php';

// Ensure the data is passed properly
if (isset($_POST['id']) && isset($_POST['grade']) && isset($_POST['comment'])) {
    $id = $_POST['id'];
    $grade = mysqli_real_escape_string($conn, $_POST['grade']);
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);

    // SQL query to update the assignment record
    $sql = "UPDATE assignments SET grade='$grade', comment='$comment' WHERE id=$id";

    // Check if the update is successful
    if (mysqli_query($conn, $sql)) {
        // Redirect with success flag
        header("Location: ../faculty/dashboard.php?updated=1");
        exit();
    } else {
        // Error message
        echo "Error updating record: " . mysqli_error($conn);
        exit();
    }
} else {
    // If the required POST data is not set, redirect back with an error
    header("Location: ../faculty/dashboard.php?error=1");
    exit();
}
?>
