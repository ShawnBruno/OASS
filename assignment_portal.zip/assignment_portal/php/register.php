<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = mysqli_real_escape_string($conn, $_POST['name']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
  $role = $_POST['role'];

  $sql = "INSERT INTO users (name, email, password, role) VALUES ('$name', '$email', '$password', '$role')";

  if (mysqli_query($conn, $sql)) {
    echo "<!DOCTYPE html>
    <html>
    <head>
      <meta http-equiv='refresh' content='3;url=../login.html'>
      <title>Registration Successful</title>
    </head>
    <body>
      <h2>Registration successful!</h2>
      <p>You will be redirected to the login page shortly...</p>
      <p><a href='/login.html'>Click here if you are not redirected</a></p>
    </body>
    </html>";
    exit();
  } else {
    echo "Error: " . mysqli_error($conn);
  }
}
?>
