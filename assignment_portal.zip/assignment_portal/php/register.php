<?php
include 'db.php';
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = mysqli_real_escape_string($conn, $_POST['name']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
  $role = $_POST['role'];

  $sql = "INSERT INTO users (name, email, password, role) VALUES ('$name', '$email', '$password', '$role')";

  try {
    if (mysqli_query($conn, $sql)) {
      echo json_encode(["status" => "success", "message" => "Registration successful. Redirecting to login..."]);
    }
  } catch (mysqli_sql_exception $e) {
    if ($e->getCode() == 1062) {  
      echo json_encode(["status" => "error", "message" => "Email is already registered. Please use a different email."]);
    } else {
      echo json_encode(["status" => "error", "message" => "An error occurred. Please try again."]);
    }
  }
}
?>
