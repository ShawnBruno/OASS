<?php
include 'db.php';

$sql = "SELECT a.id, u.name, a.filename, a.grade, a.comment FROM assignments a JOIN users u ON a.user_id = u.id";
$result = mysqli_query($conn, $sql);

while ($row = mysqli_fetch_assoc($result)) {
    echo "<form action='../php/grade.php' method='POST'>";
    echo "<p><strong>" . htmlspecialchars($row['name']) . "</strong>: ";
    echo "<a href='../uploads/" . htmlspecialchars($row['filename']) . "' download>" . htmlspecialchars($row['filename']) . "</a>";
    echo " | Grade: <input type='text' name='grade' value='" . htmlspecialchars($row['grade']) . "' size='4'>";
    echo " | Comment: <input type='text' name='comment' value='" . htmlspecialchars($row['comment']) . "' size='30'>";
    echo "<input type='hidden' name='id' value='" . htmlspecialchars($row['id']) . "'>";
    echo " <input type='submit' value='Update'></p>";
    echo "</form>";
}
?>
