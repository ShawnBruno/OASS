<?php
include 'db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$user_id = $_SESSION['user_id'] ?? 0;

$sql = "SELECT filename, grade, comment FROM assignments WHERE user_id = $user_id";
$result = mysqli_query($conn, $sql);

while ($row = mysqli_fetch_assoc($result)) {
    echo "<p>{$row['filename']} - Grade: {$row['grade']}, Comment: {$row['comment']}</p>";
}
?>
